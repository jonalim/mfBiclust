#ifndef EBIMAGE_WATERSHED_H
#define EBIMAGE_WATERSHED_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif

SEXP watershed(SEXP, SEXP, SEXP);

#ifdef __cplusplus
}
#endif

#endif
