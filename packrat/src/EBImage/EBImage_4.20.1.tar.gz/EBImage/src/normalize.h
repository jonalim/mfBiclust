#ifndef EBIMAGE_NORMALIZE_H
#define EBIMAGE_NORMALIZE_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif

SEXP normalize (SEXP, SEXP, SEXP, SEXP);

#ifdef __cplusplus
};
#endif

#endif
