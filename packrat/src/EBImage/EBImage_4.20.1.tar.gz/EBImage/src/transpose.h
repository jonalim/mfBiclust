#ifndef EBIMAGE_TRANSPOSE_H
#define EBIMAGE_TRANSPOSE_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif

SEXP transpose (SEXP);

#ifdef __cplusplus
};
#endif

#endif
