#ifndef EBIMAGE_DISTMAP_H
#define EBIMAGE_DISTMAP_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif

SEXP distmap (SEXP, SEXP);

#ifdef __cplusplus
};
#endif

#endif
