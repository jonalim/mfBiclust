library(testthat)
library(nipals)

test_check("nipals")
