
This will clearly fail at install time!
