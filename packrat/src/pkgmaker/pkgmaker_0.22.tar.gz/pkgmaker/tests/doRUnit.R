# Run all unit tests in installed directory unitTests
# 
# Author: Renaud Gaujoux
###############################################################################

pkgmaker::utest('package:pkgmaker', quiet=FALSE)
